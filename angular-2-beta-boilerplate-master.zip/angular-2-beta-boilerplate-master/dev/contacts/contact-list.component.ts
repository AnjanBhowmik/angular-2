import {Component} from 'angular2/core';
import {ContactComponent} from "./contact.component"
@Component({
    selector:"contact-list",
    template:`
         <ul>
            <li *ngFor="#contact of contacts"
            (click)="onSelect(contact)"
                    [class.clicked]="selectedContact === contact">
                    {{contact.firstName}}   {{contact.lastName}}
            </li>
    </ul>
    <contact [contact]="selectedContact"></contact>
    
    `,
    directives:[ContactComponent],
    styleUrls:["../src/css/app.css"]
})

export class ContactListComponent{
    public contacts = [
        {firstName:"Anjan", lastName:"Bhowmik", phone:"+91-750-862-3309", email:"anjanbhowmik@yahoo.com"},
        {firstName:"Riki", lastName:"Das", phone:"+91-876-862-3454", email:"RikiDas@yahoo.com"},
        {firstName:"Amit", lastName:"Das", phone:"+91-876-862-3454", email:"AmitDas@yahoo.com"},
        {firstName:"Anik", lastName:"Mandal", phone:"+91-876-862-1234", email:"anjanMandal@yahoo.com"},
        {firstName:"Mona", lastName:"Mandal", phone:"+91-987-862-1234", email:"anjanMandal@yahoo.com"}
    ];
  
    public selectedContact = {};
    onSelect (contact){
        console.log(contact);
        this.selectedContact = contact;
    }
}