System.register(['angular2/core', "./contact.component"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, contact_component_1;
    var ContactListComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (contact_component_1_1) {
                contact_component_1 = contact_component_1_1;
            }],
        execute: function() {
            ContactListComponent = (function () {
                function ContactListComponent() {
                    this.contacts = [
                        { firstName: "Anjan", lastName: "Bhowmik", phone: "+91-750-862-3309", email: "anjanbhowmik@yahoo.com" },
                        { firstName: "Riki", lastName: "Das", phone: "+91-876-862-3454", email: "RikiDas@yahoo.com" },
                        { firstName: "Amit", lastName: "Das", phone: "+91-876-862-3454", email: "AmitDas@yahoo.com" },
                        { firstName: "Anik", lastName: "Mandal", phone: "+91-876-862-1234", email: "anjanMandal@yahoo.com" },
                        { firstName: "Mona", lastName: "Mandal", phone: "+91-987-862-1234", email: "anjanMandal@yahoo.com" }
                    ];
                    this.selectedContact = {};
                }
                ContactListComponent.prototype.onSelect = function (contact) {
                    console.log(contact);
                    this.selectedContact = contact;
                };
                ContactListComponent = __decorate([
                    core_1.Component({
                        selector: "contact-list",
                        template: "\n         <ul>\n            <li *ngFor=\"#contact of contacts\"\n            (click)=\"onSelect(contact)\"\n                    [class.clicked]=\"selectedContact === contact\">\n                    {{contact.firstName}}   {{contact.lastName}}\n            </li>\n    </ul>\n    <contact [contact]=\"selectedContact\"></contact>\n    \n    ",
                        directives: [contact_component_1.ContactComponent],
                        styleUrls: ["../src/css/app.css"]
                    }), 
                    __metadata('design:paramtypes', [])
                ], ContactListComponent);
                return ContactListComponent;
            }());
            exports_1("ContactListComponent", ContactListComponent);
        }
    }
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbnRhY3RzL2NvbnRhY3QtbGlzdC5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7WUFtQkE7Z0JBQUE7b0JBQ1csYUFBUSxHQUFHO3dCQUNkLEVBQUMsU0FBUyxFQUFDLE9BQU8sRUFBRSxRQUFRLEVBQUMsU0FBUyxFQUFFLEtBQUssRUFBQyxrQkFBa0IsRUFBRSxLQUFLLEVBQUMsd0JBQXdCLEVBQUM7d0JBQ2pHLEVBQUMsU0FBUyxFQUFDLE1BQU0sRUFBRSxRQUFRLEVBQUMsS0FBSyxFQUFFLEtBQUssRUFBQyxrQkFBa0IsRUFBRSxLQUFLLEVBQUMsbUJBQW1CLEVBQUM7d0JBQ3ZGLEVBQUMsU0FBUyxFQUFDLE1BQU0sRUFBRSxRQUFRLEVBQUMsS0FBSyxFQUFFLEtBQUssRUFBQyxrQkFBa0IsRUFBRSxLQUFLLEVBQUMsbUJBQW1CLEVBQUM7d0JBQ3ZGLEVBQUMsU0FBUyxFQUFDLE1BQU0sRUFBRSxRQUFRLEVBQUMsUUFBUSxFQUFFLEtBQUssRUFBQyxrQkFBa0IsRUFBRSxLQUFLLEVBQUMsdUJBQXVCLEVBQUM7d0JBQzlGLEVBQUMsU0FBUyxFQUFDLE1BQU0sRUFBRSxRQUFRLEVBQUMsUUFBUSxFQUFFLEtBQUssRUFBQyxrQkFBa0IsRUFBRSxLQUFLLEVBQUMsdUJBQXVCLEVBQUM7cUJBQ2pHLENBQUM7b0JBRUssb0JBQWUsR0FBRyxFQUFFLENBQUM7Z0JBS2hDLENBQUM7Z0JBSkcsdUNBQVEsR0FBUixVQUFVLE9BQU87b0JBQ2IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQztvQkFDckIsSUFBSSxDQUFDLGVBQWUsR0FBRyxPQUFPLENBQUM7Z0JBQ25DLENBQUM7Z0JBOUJMO29CQUFDLGdCQUFTLENBQUM7d0JBQ1AsUUFBUSxFQUFDLGNBQWM7d0JBQ3ZCLFFBQVEsRUFBQyxzVkFVUjt3QkFDRCxVQUFVLEVBQUMsQ0FBQyxvQ0FBZ0IsQ0FBQzt3QkFDN0IsU0FBUyxFQUFDLENBQUMsb0JBQW9CLENBQUM7cUJBQ25DLENBQUM7O3dDQUFBO2dCQWdCRiwyQkFBQztZQUFELENBZEEsQUFjQyxJQUFBO1lBZEQsdURBY0MsQ0FBQSIsImZpbGUiOiJjb250YWN0cy9jb250YWN0LWxpc3QuY29tcG9uZW50LmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtDb21wb25lbnR9IGZyb20gJ2FuZ3VsYXIyL2NvcmUnO1xyXG5pbXBvcnQge0NvbnRhY3RDb21wb25lbnR9IGZyb20gXCIuL2NvbnRhY3QuY29tcG9uZW50XCJcclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjpcImNvbnRhY3QtbGlzdFwiLFxyXG4gICAgdGVtcGxhdGU6YFxyXG4gICAgICAgICA8dWw+XHJcbiAgICAgICAgICAgIDxsaSAqbmdGb3I9XCIjY29udGFjdCBvZiBjb250YWN0c1wiXHJcbiAgICAgICAgICAgIChjbGljayk9XCJvblNlbGVjdChjb250YWN0KVwiXHJcbiAgICAgICAgICAgICAgICAgICAgW2NsYXNzLmNsaWNrZWRdPVwic2VsZWN0ZWRDb250YWN0ID09PSBjb250YWN0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3tjb250YWN0LmZpcnN0TmFtZX19ICAge3tjb250YWN0Lmxhc3ROYW1lfX1cclxuICAgICAgICAgICAgPC9saT5cclxuICAgIDwvdWw+XHJcbiAgICA8Y29udGFjdCBbY29udGFjdF09XCJzZWxlY3RlZENvbnRhY3RcIj48L2NvbnRhY3Q+XHJcbiAgICBcclxuICAgIGAsXHJcbiAgICBkaXJlY3RpdmVzOltDb250YWN0Q29tcG9uZW50XSxcclxuICAgIHN0eWxlVXJsczpbXCIuLi9zcmMvY3NzL2FwcC5jc3NcIl1cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBDb250YWN0TGlzdENvbXBvbmVudHtcclxuICAgIHB1YmxpYyBjb250YWN0cyA9IFtcclxuICAgICAgICB7Zmlyc3ROYW1lOlwiQW5qYW5cIiwgbGFzdE5hbWU6XCJCaG93bWlrXCIsIHBob25lOlwiKzkxLTc1MC04NjItMzMwOVwiLCBlbWFpbDpcImFuamFuYmhvd21pa0B5YWhvby5jb21cIn0sXHJcbiAgICAgICAge2ZpcnN0TmFtZTpcIlJpa2lcIiwgbGFzdE5hbWU6XCJEYXNcIiwgcGhvbmU6XCIrOTEtODc2LTg2Mi0zNDU0XCIsIGVtYWlsOlwiUmlraURhc0B5YWhvby5jb21cIn0sXHJcbiAgICAgICAge2ZpcnN0TmFtZTpcIkFtaXRcIiwgbGFzdE5hbWU6XCJEYXNcIiwgcGhvbmU6XCIrOTEtODc2LTg2Mi0zNDU0XCIsIGVtYWlsOlwiQW1pdERhc0B5YWhvby5jb21cIn0sXHJcbiAgICAgICAge2ZpcnN0TmFtZTpcIkFuaWtcIiwgbGFzdE5hbWU6XCJNYW5kYWxcIiwgcGhvbmU6XCIrOTEtODc2LTg2Mi0xMjM0XCIsIGVtYWlsOlwiYW5qYW5NYW5kYWxAeWFob28uY29tXCJ9LFxyXG4gICAgICAgIHtmaXJzdE5hbWU6XCJNb25hXCIsIGxhc3ROYW1lOlwiTWFuZGFsXCIsIHBob25lOlwiKzkxLTk4Ny04NjItMTIzNFwiLCBlbWFpbDpcImFuamFuTWFuZGFsQHlhaG9vLmNvbVwifVxyXG4gICAgXTtcclxuICBcclxuICAgIHB1YmxpYyBzZWxlY3RlZENvbnRhY3QgPSB7fTtcclxuICAgIG9uU2VsZWN0IChjb250YWN0KXtcclxuICAgICAgICBjb25zb2xlLmxvZyhjb250YWN0KTtcclxuICAgICAgICB0aGlzLnNlbGVjdGVkQ29udGFjdCA9IGNvbnRhY3Q7XHJcbiAgICB9XHJcbn0iXSwic291cmNlUm9vdCI6Ii9zb3VyY2UvIn0=
