import {Component} from 'angular2/core';
import {CourseService} from './course.service';
import {AutoGrowDirective} from './auto-grow.directive'

@Component({
    selector:'courses',
    template:`
            <h2>Courses</h2>
            {{title}}
            <input type="text" autoGrow />
            <ul>
                <li *ngFor="#question of questions">{{question}}</li>
            </ul>
            `,
            providers:[CourseService],
            directives:[AutoGrowDirective]
})
export class CoursesComponent {
    title = "This is my Title";
    questions;
    constructor(courseService:CourseService){
        this.questions = courseService.getCourses();
    }
 }