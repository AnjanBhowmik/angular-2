
export class AuthorService {
    getAuthors(): string[] {
        return ["Author 1","Author 2","Author 3"];
    }
}