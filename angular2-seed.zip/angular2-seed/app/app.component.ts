import {Component} from 'angular2/core';
import {CoursesComponent} from './courses.component';
import {AuthorComponent} from './author.component';
@Component({
    selector: 'my-app',
    template: `
        <h1>My First Angular 2 App</h1>
        <i 
            class="glyphicon"
            [class.glyphicon-star-empty]="!isFavourite"
            [class.glyphicon-star]="isFavourite"
            (click): "onClick()">
        </i>
        <courses></courses>
        <authors></authors>
    `,
    directives:[CoursesComponent,AuthorComponent]
})
export class AppComponent { 
   isFavourite=false;
    onClick(){
        this.isFavourite = !this.isFavourite;
    }
}