
export class CourseService {
    getCourses(): string[] {
        return ["Q1. What is your name?","Q2. What you do?","Q3. What are you from?"];
    }
}